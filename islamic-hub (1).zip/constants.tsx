
import { NameInfo } from './types';

export const ALLAH_NAMES: NameInfo[] = [
  { arabic: "ٱلله", transliteration: "Allah", translation: "The One God", urdu: "اللہ" },
  { arabic: "ٱلرَّحْمَٰنُ", transliteration: "Ar-Rahman", translation: "The All-Beneficent", urdu: "نہایت مہربان" },
  { arabic: "ٱلرَّحِيمُ", transliteration: "Ar-Raheem", translation: "The Especially Merciful", urdu: "بڑا رحم والا" },
  { arabic: "ٱلْمَلِكُ", transliteration: "Al-Malik", translation: "The King", urdu: "بادشاہ" },
  { arabic: "ٱلْقُدُّوسُ", transliteration: "Al-Quddus", translation: "The Most Holy", urdu: "پاک" },
  { arabic: "ٱلسَّلَامُ", transliteration: "As-Salam", translation: "The Giver of Peace", urdu: "سلامتی دینے والا" },
  { arabic: "ٱلْمُؤْمِنُ", transliteration: "Al-Mu'min", translation: "The Giver of Belief", urdu: "امن دینے والا" },
  { arabic: "ٱلْمُهَيْمِنُ", transliteration: "Al-Muhaymin", translation: "The Guardian", urdu: "نگہبان" },
  { arabic: "ٱلْعَزِيزُ", transliteration: "Al-Aziz", translation: "The All Mighty", urdu: "غالب" },
  { arabic: "ٱلْجَبَّارُ", transliteration: "Al-Jabbar", translation: "The Compeller", urdu: "زبردست" }
];

export const MUHAMMAD_NAMES: NameInfo[] = [
  { arabic: "مُحَمَّد", transliteration: "Muhammad", translation: "The Highly Praised", urdu: "محمد" },
  { arabic: "أَحْمَد", transliteration: "Ahmad", translation: "The Most Commendable", urdu: "احمد" },
  { arabic: "حَامِد", transliteration: "Hamid", translation: "The Praiser", urdu: "حامد" },
  { arabic: "مَحْمُود", transliteration: "Mahmud", translation: "The Praised", urdu: "محمود" },
  { arabic: "قَاسِم", transliteration: "Qasim", translation: "The Distributor", urdu: "قاسم" }
];

export const TRANSLATIONS = {
  en: {
    title: "Islamic Hub",
    tasbeeh: "Tasbeeh",
    quran: "Quran",
    qibla: "Qibla",
    prayerTimes: "Prayer Times",
    allahNames: "99 Names of Allah",
    prophetNames: "99 Names of Muhammad",
    calendar: "Calendar",
    count: "Count",
    reset: "Reset",
    nextPrayer: "Next Prayer",
    distanceToKaaba: "Distance to Kaaba",
    qiblaAngle: "Qibla Angle",
    playAzan: "Play Azan",
    stopAzan: "Stop",
    searchCity: "Search Global Cities",
    downloadZip: "Download Offline ZIP",
    locationArea: "Location Area"
  },
  ur: {
    title: "اسلامک حب",
    tasbeeh: "تسبیح",
    quran: "قرآن",
    qibla: "قبلہ",
    prayerTimes: "نماز کے اوقات",
    allahNames: "اللہ کے 99 نام",
    prophetNames: "محمدؐ کے 99 نام",
    calendar: "اسلامی کیلنڈر",
    count: "تعداد",
    reset: "دوبارہ شروع",
    nextPrayer: "اگلی نماز",
    distanceToKaaba: "کعبہ سے فاصلہ",
    qiblaAngle: "زاویہ قبلہ",
    playAzan: "اذان سنیں",
    stopAzan: "روکیں",
    searchCity: "عالمی شہر تلاش کریں",
    downloadZip: "زپ فائل ڈاؤن لوڈ کریں",
    locationArea: "مقام کا علاقہ"
  }
};

export const GLOBAL_CITIES = [
  // Pakistan
  { name: "Karachi", lat: 24.8607, lon: 67.0011, country: "Pakistan" },
  { name: "Lahore", lat: 31.5204, lon: 74.3587, country: "Pakistan" },
  { name: "Faisalabad", lat: 31.4504, lon: 73.1350, country: "Pakistan" },
  { name: "Rawalpindi", lat: 33.5984, lon: 73.0441, country: "Pakistan" },
  { name: "Gujranwala", lat: 32.1877, lon: 74.1945, country: "Pakistan" },
  { name: "Peshawar", lat: 34.0151, lon: 71.5249, country: "Pakistan" },
  { name: "Multan", lat: 30.1575, lon: 71.5249, country: "Pakistan" },
  { name: "Hyderabad", lat: 25.3960, lon: 68.3578, country: "Pakistan" },
  { name: "Islamabad", lat: 33.6844, lon: 73.0479, country: "Pakistan" },
  { name: "Quetta", lat: 30.1798, lon: 66.9750, country: "Pakistan" },
  // Saudi Arabia
  { name: "Mecca", lat: 21.4225, lon: 39.8262, country: "Saudi Arabia" },
  { name: "Medina", lat: 24.4672, lon: 39.6024, country: "Saudi Arabia" },
  { name: "Riyadh", lat: 24.7136, lon: 46.6753, country: "Saudi Arabia" },
  { name: "Jeddah", lat: 21.5433, lon: 39.1728, country: "Saudi Arabia" },
  { name: "Dammam", lat: 26.4207, lon: 50.0888, country: "Saudi Arabia" },
  // India
  { name: "Mumbai", lat: 19.0760, lon: 72.8777, country: "India" },
  { name: "Delhi", lat: 28.6139, lon: 77.2090, country: "India" },
  { name: "Bangalore", lat: 12.9716, lon: 77.5946, country: "India" },
  { name: "Hyderabad (IN)", lat: 17.3850, lon: 78.4867, country: "India" },
  { name: "Ahmedabad", lat: 23.0225, lon: 72.5714, country: "India" },
  // USA
  { name: "New York", lat: 40.7128, lon: -74.0060, country: "USA" },
  { name: "Los Angeles", lat: 34.0522, lon: -118.2437, country: "USA" },
  { name: "Chicago", lat: 41.8781, lon: -87.6298, country: "USA" },
  // UK
  { name: "London", lat: 51.5074, lon: -0.1278, country: "UK" },
  { name: "Birmingham", lat: 52.4862, lon: -1.8904, country: "UK" },
  // Turkey
  { name: "Istanbul", lat: 41.0082, lon: 28.9784, country: "Turkey" },
  { name: "Ankara", lat: 39.9334, lon: 32.8597, country: "Turkey" },
  // Egypt
  { name: "Cairo", lat: 30.0444, lon: 31.2357, country: "Egypt" },
  // Indonesia
  { name: "Jakarta", lat: -6.2088, lon: 106.8456, country: "Indonesia" },
  { name: "Surabaya", lat: -7.2575, lon: 112.7521, country: "Indonesia" }
];
