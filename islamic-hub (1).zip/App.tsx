
import React, { useState, useEffect } from 'react';
import { Tab, Language, PrayerTimes } from './types';
import { TRANSLATIONS } from './constants';
import Dashboard from './components/Dashboard';
import QuranReader from './components/QuranReader';
import NamesList from './components/NamesList';
import TasbeehCounter from './components/TasbeehCounter';
import QiblaCompass from './components/QiblaCompass';
import IslamicCalendar from './components/IslamicCalendar';
import Sidebar from './components/Sidebar';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>(Tab.Home);
  const [lang, setLang] = useState<Language>('en');
  const [location, setLocation] = useState<{lat: number, lon: number} | null>(null);
  const [prayerTimes, setPrayerTimes] = useState<PrayerTimes | null>(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lon = pos.coords.longitude;
          setLocation({ lat, lon });
          fetchPrayerTimes(lat, lon);
        },
        () => {
          // Fallback to Makkah
          const lat = 21.4225;
          const lon = 39.8262;
          setLocation({ lat, lon });
          fetchPrayerTimes(lat, lon);
        }
      );
    }
  }, []);

  const fetchPrayerTimes = async (lat: number, lon: number) => {
    try {
      setPrayerTimes(null); // Reset for loading state
      const response = await fetch(`https://api.aladhan.com/v1/timings?latitude=${lat}&longitude=${lon}&method=2`);
      const data = await response.json();
      setPrayerTimes(data.data.timings);
    } catch (error) {
      console.error("Error fetching prayer times", error);
    }
  };

  const handleCityChange = (lat: number, lon: number) => {
    setLocation({ lat, lon });
    fetchPrayerTimes(lat, lon);
  };

  const renderContent = () => {
    switch (activeTab) {
      case Tab.Home: return <Dashboard lang={lang} prayerTimes={prayerTimes} location={location} onCityChange={handleCityChange} />;
      case Tab.Quran: return <QuranReader lang={lang} />;
      case Tab.Names: return <NamesList lang={lang} />;
      case Tab.Tasbeeh: return <TasbeehCounter lang={lang} />;
      case Tab.Qibla: return <QiblaCompass lang={lang} location={location} />;
      case Tab.Calendar: return <IslamicCalendar lang={lang} />;
      default: return <Dashboard lang={lang} prayerTimes={prayerTimes} location={location} />;
    }
  };

  const t = TRANSLATIONS[lang];

  return (
    <div className={`min-h-screen flex bg-slate-50 ${lang === 'ur' ? 'flex-row-reverse' : 'flex-row'}`} dir={lang === 'ur' ? 'rtl' : 'ltr'}>
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} lang={lang} />
      
      <main className="flex-1 p-4 md:p-8 overflow-y-auto pb-24 md:pb-8">
        <header className="flex justify-between items-center mb-8 bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
          <h1 className="text-2xl font-bold text-emerald-700 flex items-center gap-2">
            <i className="fa-solid fa-mosque"></i>
            {t.title}
          </h1>
          <button 
            onClick={() => setLang(lang === 'en' ? 'ur' : 'en')}
            className="px-4 py-2 bg-emerald-100 text-emerald-800 rounded-lg font-medium hover:bg-emerald-200 transition-colors"
          >
            {lang === 'en' ? 'اردو' : 'English'}
          </button>
        </header>

        <div className="max-w-6xl mx-auto">
          {renderContent()}
        </div>
      </main>

      {/* Mobile Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 flex justify-around p-2 md:hidden z-50">
        {[Tab.Home, Tab.Quran, Tab.Qibla, Tab.Tasbeeh].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`p-3 rounded-xl flex flex-col items-center gap-1 ${activeTab === tab ? 'text-emerald-600 bg-emerald-50' : 'text-slate-400'}`}
          >
            <i className={`fa-solid fa-${tab === Tab.Home ? 'house' : tab === Tab.Quran ? 'book-quran' : tab === Tab.Qibla ? 'compass' : 'calculator'}`}></i>
            <span className="text-[10px] uppercase font-bold">{t[tab as keyof typeof t] || tab}</span>
          </button>
        ))}
      </nav>
    </div>
  );
};

export default App;
