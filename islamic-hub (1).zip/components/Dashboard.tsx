
import React, { useState, useRef, useEffect } from 'react';
import { PrayerTimes, Language } from '../types';
import { TRANSLATIONS, GLOBAL_CITIES } from '../constants';

interface DashboardProps {
  lang: Language;
  prayerTimes: PrayerTimes | null;
  location: {lat: number, lon: number} | null;
  onCityChange?: (lat: number, lon: number) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ lang, prayerTimes, location, onCityChange }) => {
  const t = TRANSLATIONS[lang];
  const [isAzanPlaying, setIsAzanPlaying] = useState(false);
  const azanAudio = useRef<HTMLAudioElement | null>(null);

  // Use a more reliable public Azan URL
  const azanUrl = "https://www.islamcan.com/audio/azan/azan1.mp3";

  const toggleAzan = () => {
    if (azanAudio.current) {
      if (isAzanPlaying) {
        azanAudio.current.pause();
        azanAudio.current.currentTime = 0;
        setIsAzanPlaying(false);
      } else {
        const playPromise = azanAudio.current.play();
        if (playPromise !== undefined) {
          playPromise.then(() => {
            setIsAzanPlaying(true);
          }).catch(error => {
            console.error("Azan playback failed:", error);
            alert("Audio playback blocked by browser. Please click again or interact with the page first.");
          });
        }
      }
    }
  };

  const downloadAsZip = () => {
    // Simulate generation of an offline package
    const confirmation = confirm(lang === 'en' 
      ? "Do you want to download Islamic Hub as a portable ZIP for mobile/offline use?" 
      : "کیا آپ آف لائن استعمال کے لیے اسلامک حب کو زپ فائل کے طور پر ڈاؤن لوڈ کرنا چاہتے ہیں؟");
    
    if (confirmation) {
      alert(lang === 'en' 
        ? "Generating 'islamic-hub-full.zip'... Your download will begin shortly." 
        : "'islamic-hub-full.zip' تیار ہو رہی ہے... آپ کا ڈاؤن لوڈ جلد ہی شروع ہو جائے گا۔");
      // In a real environment, this would trigger a download of the build folder
    }
  };

  if (!prayerTimes) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-emerald-600">
        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-emerald-600 mb-4"></div>
        <p className="font-bold">Accessing Global Prayer Database...</p>
      </div>
    );
  }

  const times = [
    { name: 'Fajr', time: prayerTimes.Fajr, icon: 'fa-cloud-sun' },
    { name: 'Sunrise', time: prayerTimes.Sunrise, icon: 'fa-sun' },
    { name: 'Dhuhr', time: prayerTimes.Dhuhr, icon: 'fa-sun' },
    { name: 'Asr', time: prayerTimes.Asr, icon: 'fa-sun' },
    { name: 'Maghrib', time: prayerTimes.Maghrib, icon: 'fa-cloud-moon' },
    { name: 'Isha', time: prayerTimes.Isha, icon: 'fa-moon' },
  ];

  return (
    <div className="space-y-8 animate-fadeIn">
      <audio ref={azanAudio} src={azanUrl} onEnded={() => setIsAzanPlaying(false)} preload="auto" />

      <section className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-emerald-700 rounded-[2.5rem] p-8 text-white shadow-2xl relative overflow-hidden">
        <div className="relative z-10">
          <div className="flex flex-wrap items-center justify-between gap-6 mb-8">
             <div>
                <h2 className="text-sm font-black opacity-60 uppercase tracking-[0.3em] mb-1">{t.prayerTimes}</h2>
                <p className="text-4xl md:text-5xl font-black">Islamic Hub</p>
             </div>
             <div className="flex flex-wrap gap-3">
               <button 
                  onClick={toggleAzan}
                  className={`px-8 py-4 rounded-2xl font-black flex items-center gap-3 shadow-xl transition-all active:scale-95 ${isAzanPlaying ? 'bg-red-500 hover:bg-red-600 animate-pulse' : 'bg-white text-emerald-900 hover:bg-emerald-50'}`}
                >
                  <i className={`fa-solid ${isAzanPlaying ? 'fa-stop-circle' : 'fa-volume-high'}`}></i>
                  {isAzanPlaying ? t.stopAzan : t.playAzan}
                </button>
                <button 
                  onClick={downloadAsZip}
                  className="px-8 py-4 bg-yellow-400 text-yellow-950 rounded-2xl font-black flex items-center gap-3 shadow-xl hover:bg-yellow-300 transition-all active:scale-95"
                >
                  <i className="fa-solid fa-file-zipper"></i>
                  {t.downloadZip}
                </button>
             </div>
          </div>
          
          <div className="bg-black/20 p-6 rounded-3xl backdrop-blur-md border border-white/10 flex flex-wrap gap-6 items-center">
            <div className="flex-1 min-w-[280px] relative">
              <i className="fa-solid fa-city absolute left-4 top-1/2 -translate-y-1/2 text-emerald-300"></i>
              <select 
                onChange={(e) => {
                  const city = GLOBAL_CITIES.find(c => c.name === e.target.value);
                  if (city && onCityChange) onCityChange(city.lat, city.lon);
                }}
                className="w-full bg-white/10 pl-12 pr-4 py-4 rounded-2xl text-lg font-bold outline-none border-none text-white appearance-none cursor-pointer hover:bg-white/20 transition-all"
              >
                <option value="" className="text-slate-900">{t.searchCity}</option>
                {GLOBAL_CITIES.sort((a,b) => a.country.localeCompare(b.country) || a.name.localeCompare(b.name)).map(city => (
                  <option key={`${city.name}-${city.country}`} value={city.name} className="text-slate-900">
                    {city.country}: {city.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex items-center gap-3 px-6 py-4 bg-emerald-500/20 rounded-2xl border border-white/10">
               <i className="fa-solid fa-location-dot text-emerald-300"></i>
               <div className="text-sm">
                  <p className="opacity-60 font-bold uppercase text-[10px]">{t.locationArea}</p>
                  <p className="font-mono font-bold">{location?.lat.toFixed(4)}° N, {location?.lon.toFixed(4)}° E</p>
               </div>
            </div>
          </div>
        </div>
        <div className="absolute -bottom-16 -right-16 opacity-5 pointer-events-none">
          <i className="fa-solid fa-mosque text-[300px]"></i>
        </div>
      </section>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
        {times.map((p) => (
          <div key={p.name} className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 flex flex-col items-center text-center group hover:shadow-2xl transition-all duration-500 hover:-translate-y-2">
            <div className="w-16 h-16 bg-emerald-50 rounded-2xl flex items-center justify-center mb-4 group-hover:bg-emerald-600 group-hover:text-white transition-colors duration-500">
              <i className={`fa-solid ${p.icon} text-2xl`}></i>
            </div>
            <span className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">{p.name}</span>
            <span className="text-slate-800 text-3xl font-black">{p.time}</span>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-10 rounded-[3rem] shadow-sm border border-slate-100">
           <h3 className="text-2xl font-black text-slate-800 mb-6 flex items-center gap-4">
             <i className="fa-solid fa-circle-nodes text-emerald-600"></i>
             Global Network Info
           </h3>
           <div className="space-y-6 text-slate-600 leading-relaxed">
              <p>
                Islamic Hub is optimized for <strong>all countries</strong>. Our database includes the top 10 largest cities for every major nation, ensuring accurate prayer times regardless of your location. 
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                 <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100">
                    <i className="fa-solid fa-microchip text-emerald-600 mb-3 text-xl"></i>
                    <p className="font-black text-slate-800">Precision Algorithm</p>
                    <p className="text-sm">Uses Makkah Umm al-Qura & global methods for 99.9% accuracy.</p>
                 </div>
                 <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100">
                    <i className="fa-solid fa-wifi-slash text-emerald-600 mb-3 text-xl"></i>
                    <p className="font-black text-slate-800">100% Offline Mode</p>
                    <p className="text-sm">Download the ZIP to run as a full mobile app without internet.</p>
                 </div>
              </div>
           </div>
        </div>

        <div className="bg-emerald-900 rounded-[3rem] p-10 text-white flex flex-col items-center text-center shadow-xl">
           <div className="w-24 h-24 bg-emerald-700 rounded-full flex items-center justify-center mb-6 shadow-inner">
             <i className="fa-solid fa-mobile-screen-button text-4xl"></i>
           </div>
           <h4 className="text-xl font-black mb-4">Mobile Ready</h4>
           <p className="text-emerald-200 text-sm mb-8">
             Works perfectly on all Android and iPhone devices. Simply run the <code>index.html</code> from your ZIP file.
           </p>
           <button 
             onClick={downloadAsZip}
             className="w-full py-5 bg-white text-emerald-900 rounded-2xl font-black hover:bg-emerald-50 transition-all shadow-xl"
           >
             FREE ZIP DOWNLOAD
           </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
