
import React, { useState } from 'react';
import { Language } from '../types';
import { TRANSLATIONS } from '../constants';

const TasbeehCounter: React.FC<{ lang: Language }> = ({ lang }) => {
  const [count, setCount] = useState(0);
  const t = TRANSLATIONS[lang];

  const handleIncrement = () => {
    setCount(prev => prev + 1);
    // Haptic feedback if available
    if (navigator.vibrate) navigator.vibrate(50);
  };

  return (
    <div className="max-w-md mx-auto bg-white p-8 rounded-[3rem] shadow-xl border border-slate-100 text-center">
      <h2 className="text-2xl font-bold text-slate-800 mb-8">{t.tasbeeh}</h2>
      
      <div className="relative inline-block mb-10">
        <div className="w-48 h-48 rounded-full border-[10px] border-emerald-500 flex items-center justify-center bg-slate-50 shadow-inner">
          <span className="text-6xl font-black text-emerald-700 font-mono tracking-tighter">
            {count.toString().padStart(3, '0')}
          </span>
        </div>
        <div className="absolute top-0 right-0 w-8 h-8 bg-emerald-500 rounded-full border-4 border-white"></div>
      </div>

      <div className="space-y-4">
        <button 
          onClick={handleIncrement}
          className="w-full py-8 bg-emerald-600 text-white rounded-3xl font-bold text-2xl shadow-xl shadow-emerald-200 active:scale-95 active:bg-emerald-700 transition-all"
        >
          {t.count}
        </button>
        
        <button 
          onClick={() => setCount(0)}
          className="w-full py-4 text-slate-400 hover:text-red-500 font-bold transition-colors uppercase tracking-widest text-sm"
        >
          <i className="fa-solid fa-rotate-left mr-2"></i>
          {t.reset}
        </button>
      </div>

      <div className="mt-8 pt-6 border-t border-slate-100 flex justify-around text-slate-400">
        <div className="flex flex-col items-center">
          <span className="text-xs font-bold">Total Session</span>
          <span className="text-lg font-bold text-slate-700">{count}</span>
        </div>
        <div className="flex flex-col items-center">
          <span className="text-xs font-bold">Target</span>
          <span className="text-lg font-bold text-slate-700">33 / 100</span>
        </div>
      </div>
    </div>
  );
};

export default TasbeehCounter;
