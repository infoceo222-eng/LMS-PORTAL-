
import React from 'react';
import { Language } from '../types';

const IslamicCalendar: React.FC<{ lang: Language }> = ({ lang }) => {
  const today = new Date();
  const options: Intl.DateTimeFormatOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  const gregDate = today.toLocaleDateString(lang === 'en' ? 'en-US' : 'ur-PK', options);
  
  // Dummy hijri date for UI (would usually fetch from API)
  const hijriDay = 15;
  const hijriMonth = "Ramadan";
  const hijriYear = 1446;

  return (
    <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100">
      <div className="flex flex-col md:flex-row gap-8 items-center justify-between mb-12">
        <div className="text-center md:text-left">
          <p className="text-emerald-600 font-bold uppercase tracking-widest text-sm mb-2">Current Date</p>
          <h2 className="text-3xl font-bold text-slate-800">{gregDate}</h2>
        </div>
        <div className="bg-emerald-700 text-white p-8 rounded-[2rem] text-center shadow-xl md:w-64">
           <p className="text-sm opacity-80 uppercase font-bold mb-1">Hijri Date</p>
           <p className="text-5xl font-black">{hijriDay}</p>
           <p className="text-xl font-bold mt-2 uppercase">{hijriMonth}</p>
           <p className="text-lg opacity-80">{hijriYear} AH</p>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-2">
        {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map(d => (
          <div key={d} className="text-center p-2 text-xs font-bold text-slate-400 uppercase">{d}</div>
        ))}
        {Array.from({ length: 30 }).map((_, i) => (
          <div 
            key={i} 
            className={`aspect-square flex items-center justify-center rounded-xl text-lg font-medium transition-colors ${
              i + 1 === hijriDay 
              ? 'bg-emerald-600 text-white font-bold scale-110 shadow-lg' 
              : 'bg-slate-50 text-slate-600 hover:bg-slate-100 cursor-pointer'
            }`}
          >
            {i + 1}
          </div>
        ))}
      </div>
    </div>
  );
};

export default IslamicCalendar;
