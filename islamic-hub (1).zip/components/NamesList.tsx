
import React, { useState } from 'react';
import { ALLAH_NAMES, MUHAMMAD_NAMES, TRANSLATIONS } from '../constants';
import { Language } from '../types';

const NamesList: React.FC<{ lang: Language }> = ({ lang }) => {
  const [activeSet, setActiveSet] = useState<'allah' | 'prophet'>('allah');
  const t = TRANSLATIONS[lang];
  const names = activeSet === 'allah' ? ALLAH_NAMES : MUHAMMAD_NAMES;

  return (
    <div className="space-y-6">
      <div className="flex bg-slate-100 p-1 rounded-2xl w-full max-w-sm mx-auto mb-8">
        <button 
          onClick={() => setActiveSet('allah')}
          className={`flex-1 py-3 rounded-xl font-bold transition-all ${activeSet === 'allah' ? 'bg-white text-emerald-700 shadow-sm' : 'text-slate-500'}`}
        >
          {t.allahNames}
        </button>
        <button 
          onClick={() => setActiveSet('prophet')}
          className={`flex-1 py-3 rounded-xl font-bold transition-all ${activeSet === 'prophet' ? 'bg-white text-emerald-700 shadow-sm' : 'text-slate-500'}`}
        >
          {t.prophetNames}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {names.map((name, i) => (
          <div key={i} className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 text-center hover:shadow-md transition-shadow">
            <div className="text-slate-300 font-bold mb-2"># {i + 1}</div>
            <div className="arabic-font text-5xl text-emerald-700 mb-4 font-bold h-20 flex items-center justify-center">
              {name.arabic}
            </div>
            <div className="space-y-1">
              <h3 className="font-bold text-slate-800 text-lg uppercase tracking-tight">{name.transliteration}</h3>
              <p className="text-slate-500 italic text-sm">{name.translation}</p>
              {lang === 'ur' && (
                <p className="text-emerald-600 font-bold text-lg pt-2 border-t mt-2">{name.urdu}</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default NamesList;
