
import React, { useState, useEffect } from 'react';
import { Language } from '../types';
import { TRANSLATIONS } from '../constants';

interface QiblaProps {
  lang: Language;
  location: {lat: number, lon: number} | null;
}

const QiblaCompass: React.FC<QiblaProps> = ({ lang, location }) => {
  const [qiblaDir, setQiblaDir] = useState<number>(0);
  const [distance, setDistance] = useState<number>(0);
  const t = TRANSLATIONS[lang];

  useEffect(() => {
    if (location) {
      calculateQibla(location.lat, location.lon);
    }
  }, [location]);

  const calculateQibla = (lat: number, lng: number) => {
    const kaabaLat = 21.4225;
    const kaabaLng = 39.8262;

    const y = Math.sin(Math.PI * (kaabaLng - lng) / 180);
    const x = Math.cos(Math.PI * lat / 180) * Math.tan(Math.PI * kaabaLat / 180) - 
              Math.sin(Math.PI * lat / 180) * Math.cos(Math.PI * (kaabaLng - lng) / 180);
    
    let dir = Math.atan2(y, x) * 180 / Math.PI;
    if (dir < 0) dir += 360;
    setQiblaDir(dir);

    const R = 6371;
    const dLat = (kaabaLat - lat) * Math.PI / 180;
    const dLon = (kaabaLng - lng) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat * Math.PI / 180) * Math.cos(kaabaLat * Math.PI / 180) *
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    setDistance(R * c);
  };

  return (
    <div className="flex flex-col items-center gap-8 py-10 animate-fadeIn">
      <div className="text-center bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 w-full max-w-2xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-around gap-8">
          <div className="space-y-1">
             <h2 className="text-4xl font-black text-slate-800">{t.qibla}</h2>
             <p className="text-emerald-600 font-bold uppercase tracking-widest text-xs">Global Compass</p>
          </div>
          <div className="flex gap-8">
            <div className="text-center">
              <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">{t.distanceToKaaba}</p>
              <p className="text-slate-800 font-black text-3xl">{Math.round(distance).toLocaleString()} <span className="text-sm font-normal">km</span></p>
            </div>
            <div className="text-center border-l border-slate-100 pl-8">
              <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">{t.qiblaAngle}</p>
              <p className="text-slate-800 font-black text-3xl">{qiblaDir.toFixed(1)}°</p>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 p-4 opacity-5">
           <i className="fa-solid fa-kaaba text-8xl"></i>
        </div>
      </div>

      <div className="relative w-[320px] h-[320px] md:w-[450px] md:h-[450px]">
        {/* Outer Ring */}
        <div className="absolute inset-0 rounded-full border-[16px] border-slate-100 bg-white shadow-2xl flex items-center justify-center">
           <div className="absolute inset-[10%] rounded-full border border-emerald-50 bg-emerald-50/20"></div>
        </div>
        
        {/* Compass Markers */}
        <div className="absolute inset-8 border border-slate-200 rounded-full pointer-events-none">
           {[...Array(72)].map((_, i) => (
             <div key={i} className={`absolute w-1 h-2 bg-slate-200 left-1/2 -translate-x-1/2 origin-[0_130px] md:origin-[0_180px]`} style={{ transform: `rotate(${i * 5}deg) translateY(-130px) md:translateY(-180px)` }}></div>
           ))}
        </div>

        <span className="absolute top-8 left-1/2 -translate-x-1/2 font-black text-slate-800 text-xl">N</span>
        <span className="absolute bottom-8 left-1/2 -translate-x-1/2 font-black text-slate-400 text-xl">S</span>
        <span className="absolute left-8 top-1/2 -translate-y-1/2 font-black text-slate-400 text-xl">W</span>
        <span className="absolute right-8 top-1/2 -translate-y-1/2 font-black text-slate-400 text-xl">E</span>

        {/* The Needle */}
        <div 
          className="absolute inset-0 flex items-center justify-center qibla-needle"
          style={{ transform: `rotate(${qiblaDir}deg)` }}
        >
          {/* North/Qibla pointer */}
          <div className="w-2 h-[45%] bg-emerald-600 absolute bottom-1/2 rounded-full origin-bottom shadow-lg z-20"></div>
          {/* South tail */}
          <div className="w-2 h-[20%] bg-slate-200 absolute top-1/2 rounded-full origin-top z-10"></div>
          
          <div className="w-16 h-16 bg-emerald-600 rounded-3xl rotate-45 flex items-center justify-center shadow-xl border-8 border-white z-30 transform hover:scale-110 transition-transform">
             <i className="fa-solid fa-kaaba text-white text-xl -rotate-45"></i>
          </div>
        </div>

        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-40">
          <div className="w-2 h-2 bg-white rounded-full border-2 border-emerald-600"></div>
        </div>
      </div>

      <div className="bg-emerald-900 p-8 rounded-[2rem] text-white shadow-2xl shadow-emerald-200 max-w-xl w-full text-center relative overflow-hidden group">
        <div className="relative z-10">
          <p className="font-bold text-lg mb-2">Facing the Kaaba</p>
          <p className="text-emerald-100 text-sm leading-relaxed">
            Your location is detected as <span className="text-white font-black">{location?.lat.toFixed(2)}°, {location?.lon.toFixed(2)}°</span>. Rotate your phone or screen until the Kaaba icon points to the top to face Mecca.
          </p>
        </div>
        <div className="absolute -left-4 -bottom-4 opacity-10 group-hover:scale-110 transition-transform">
           <i className="fa-solid fa-compass text-9xl"></i>
        </div>
      </div>
    </div>
  );
};

export default QiblaCompass;
