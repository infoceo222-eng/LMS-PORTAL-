
import React from 'react';
import { Tab, Language } from '../types';
import { TRANSLATIONS } from '../constants';

interface SidebarProps {
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
  lang: Language;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, lang }) => {
  const t = TRANSLATIONS[lang];
  
  const menuItems = [
    { id: Tab.Home, icon: 'fa-house', label: lang === 'en' ? 'Dashboard' : 'ڈیش بورڈ' },
    { id: Tab.Quran, icon: 'fa-book-quran', label: t.quran },
    { id: Tab.Qibla, icon: 'fa-compass', label: t.qibla },
    { id: Tab.Names, icon: 'fa-star-and-crescent', label: lang === 'en' ? 'Names' : 'نام مبارک' },
    { id: Tab.Tasbeeh, icon: 'fa-calculator', label: t.tasbeeh },
    { id: Tab.Calendar, icon: 'fa-calendar-days', label: t.calendar },
  ];

  return (
    <aside className="hidden md:flex flex-col w-64 bg-white border-r border-slate-200 p-6 h-screen sticky top-0">
      <div className="mb-10 text-emerald-800 font-bold text-2xl px-2">
        <i className="fa-solid fa-kaaba mr-2"></i>
        Islamic Hub
      </div>
      <nav className="space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all duration-200 ${
              activeTab === item.id 
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200' 
              : 'text-slate-600 hover:bg-emerald-50 hover:text-emerald-700'
            }`}
          >
            <i className={`fa-solid ${item.icon} w-6`}></i>
            <span className="font-semibold">{item.label}</span>
          </button>
        ))}
      </nav>
      
      <div className="mt-auto p-4 bg-emerald-50 rounded-2xl border border-emerald-100">
        <p className="text-emerald-800 text-xs font-bold uppercase tracking-wider mb-2">Daily Verse</p>
        <p className="text-emerald-700 italic text-sm">"Verily, with hardship comes ease." (94:6)</p>
      </div>
    </aside>
  );
};

export default Sidebar;
