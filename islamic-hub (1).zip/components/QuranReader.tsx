
import React, { useState, useEffect } from 'react';
import { Surah, Language } from '../types';

const QuranReader: React.FC<{ lang: Language }> = ({ lang }) => {
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedSurah, setSelectedSurah] = useState<number | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = React.useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    fetch('https://api.alquran.cloud/v1/surah')
      .then(res => res.json())
      .then(data => {
        setSurahs(data.data);
        setLoading(false);
      });
  }, []);

  const playSurahAudio = (number: number) => {
    if (selectedSurah === number && isPlaying) {
      audioRef.current?.pause();
      setIsPlaying(false);
    } else {
      setSelectedSurah(number);
      // Using global Quran reciter for Urdu translation audio (example API)
      const audioUrl = `https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/${number}.mp3`;
      if (audioRef.current) {
        audioRef.current.src = audioUrl;
        audioRef.current.play();
        setIsPlaying(true);
      }
    }
  };

  if (loading) return <div className="text-center py-20 text-emerald-600"><i className="fas fa-spinner fa-spin fa-2x"></i></div>;

  return (
    <div className="space-y-6">
      <audio ref={audioRef} onEnded={() => setIsPlaying(false)} className="hidden" />
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {surahs.map((surah) => (
          <div 
            key={surah.number} 
            className={`bg-white p-5 rounded-2xl shadow-sm border-2 transition-all cursor-pointer group flex items-center gap-4 ${
              selectedSurah === surah.number ? 'border-emerald-500 bg-emerald-50' : 'border-slate-100 hover:border-emerald-200'
            }`}
          >
            <div className="w-10 h-10 bg-emerald-100 text-emerald-700 rounded-lg flex items-center justify-center font-bold shrink-0">
              {surah.number}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-slate-800 truncate">{surah.englishName}</h3>
              <p className="text-xs text-slate-500 truncate">{surah.englishNameTranslation}</p>
            </div>
            <div className="text-right">
              <p className="arabic-font text-emerald-700 font-bold text-xl">{surah.name}</p>
              <button 
                onClick={(e) => { e.stopPropagation(); playSurahAudio(surah.number); }}
                className="mt-2 text-emerald-600 hover:text-emerald-800 transition-colors"
              >
                <i className={`fa-solid ${selectedSurah === surah.number && isPlaying ? 'fa-circle-pause' : 'fa-circle-play'} text-2xl`}></i>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default QuranReader;
