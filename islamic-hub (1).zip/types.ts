
export type Language = 'en' | 'ur';

export interface PrayerTimes {
  Fajr: string;
  Sunrise: string;
  Dhuhr: string;
  Asr: string;
  Maghrib: string;
  Isha: string;
}

export interface Surah {
  number: number;
  name: string;
  englishName: string;
  englishNameTranslation: string;
  numberOfAyahs: number;
  revelationType: string;
}

export interface NameInfo {
  arabic: string;
  transliteration: string;
  translation: string;
  urdu: string;
}

export enum Tab {
  Home = 'home',
  Quran = 'quran',
  Names = 'names',
  Tasbeeh = 'tasbeeh',
  Qibla = 'qibla',
  Calendar = 'calendar'
}
